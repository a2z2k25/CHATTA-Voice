#!/bin/bash
# CHATTA MCP Server Launcher
cd "/Users/az/Claude/bumba-claude/CHATTA 1.0"
export STT_BASE_URL="http://localhost:8880/v1"
export TTS_BASE_URL="http://localhost:7888/v1"
export PREFER_LOCAL="true"
export OPENAI_API_KEY="dummy-key-for-local"
export PYTHONPATH="/Users/az/Claude/bumba-claude/CHATTA 1.0"
export PYTHONUNBUFFERED=1
# Suppress Python warnings that would break JSON-RPC
export PYTHONWARNINGS="ignore"

# Use the venv Python
exec /Users/az/Claude/bumba-claude/CHATTA\ 1.0/.venv/bin/python -m voice_mode.server